import os
import re
import time
import argparse

# mscid = {old_str1, new_str1}
# MSISDN = {old_str2, new_str2}
# mscid = r"24081"
# MSISDN = r"3465789"

parser = argparse.ArgumentParser(description='Get some msci MISIDN basefile parameters.')
parser.add_argument('--mscid', type=str, required=True, help='mscid base value full num, for example "460080000000000" end with 0')
parser.add_argument('--MSISDN', type=str, required=True, help='MSISDN base value full num, for example "463181000000000" end with 0')
parser.add_argument('--old_mscid', type=str, required=True, help='old imsi which is ready to replace, for example 460080000000102')
parser.add_argument('--old_MSISDN', type=str, required=True, help='old MSISDN which is ready to replace, for example 463181000000102')
parser.add_argument('--basefile', type=str, required=True, help='base file for example UDM_sub_102.ldif')
args = parser.parse_args()
mscid = args.mscid
MSISDN = args.MSISDN
old_mscid = args.old_mscid
old_MSISDN = args.old_MSISDN
basefile = args.basefile
#basefile = "UDM_sub_102.ldif"
#print 'type(mscid)',type(mscid)
#print 'type(MSISDN)',type(MSISDN)
#print 'type(old_mscid)',type(old_mscid)
#print 'type(old_mscid)',type(old_MSISDN)
#print 'type(basefile)',type(basefile)
#print 'mscid:',mscid
#print 'MSISDN:',MSISDN
#print 'old_mscid:',old_mscid
#print 'old_MSISDN:',old_MSISDN
#print 'basefile:',basefile

def release_imsi(i):
    old_str1 = old_mscid
    new_str1 = str(int(mscid) + i)
    old_str2 = old_MSISDN
    new_str2 = str(int(MSISDN) + i)
    old_file = basefile
    new_file = r'UDM_sub_0' + str(i) + r'.ldif'
    command1 = r'/home/eccd/ldapdelete -h 10.0.10.10 -p 31389 -D "cn=manager,dc=operator,dc=com" -w normal -r "IMSI=' + new_str1 + r',dc=IMSI,ou=identities,dc=operator,dc=com"'
    command2 = r'/home/eccd/ldapdelete -h 10.0.10.10 -p 31389 -D "cn=manager,dc=operator,dc=com" -w normal -r "mscId=' + new_str1 + r',ou=multiSCs,dc=operator,dc=com"'
    command3 = r'/home/eccd/ldapdelete -h 10.0.10.10 -p 31389 -D "cn=manager,dc=operator,dc=com" -w normal -r "TRAFFICID='+ new_str1 + r',dc=TRAFFICID,ou=identities,dc=operator,dc=com"'
#    print 'insert cmmand1:', command1
#    print 'insert cmmand2:', command2
#    print 'insert cmmand3:', command3
    os.system(command1)
    os.system(command2)
    os.system(command3)
    time.sleep(0.1)
    os.system(r'rm ' + new_file)


def check_misi(m,n):
    try:
        with open("check_result.txt", 'w') as ff:
            for i in range(m, n + 1):
                old_str1 = old_mscid
                new_str1 = str(int(mscid) + i)
                old_str2 = old_MSISDN
                new_str2 = str(int(MSISDN) + i)
                old_file = basefile
                new_file = r'UDM_sub_0' + str(i) + r'.ldif'
                cmd = r'/home/eccd/ldapsearch -h 10.0.10.10 -p 31389 -x -D "cn=manager,dc=operator,dc=com" -w normal -s sub -a always -b imsi=' + new_str1 + r',dc=imsi,ou=identities,dc=operator,dc=com'
                print 'search command:', cmd
                p = os.popen(cmd)
                list_line = p.readlines()
                # print 'type(list_line[0]):', type(list_line[0])
                flag = 0
                for ll in list_line:
                    ss = str(ll)
                    if "result: 0 Success" in str(ll):
                        flag = 1
                        # print ll
                        break
                if not flag:
                    print 'not ok'
                    ff.write("\033[0;31mimsi:%s insert Fail or not in the Database\n" % (new_str1))
                else:
                    print 'ok'
                    ff.write("\033[0;32mimsi:%s add to Database Success\n" % (new_str1))
    except Exception as error:
        print "Error in open check_result file"
    finally:
        ff.close()
    print '\n\n\033[0;36mcheck result as below:'
    os.system("cat check_result.txt")


def insert_misi(i):
    old_str1 = old_mscid
    new_str1 = str(int(mscid) + i)
    old_str2 = old_MSISDN
    new_str2 = str(int(MSISDN) + i)
    old_file = basefile
    new_file = r'UDM_sub_0' + str(i) + r'.ldif'
#    print 'old_str1',old_str1
#    print 'new_str1',new_str1
#    print 'old_str2',old_str2
#    print 'new_str2',new_str2
    try:
        with open(old_file, "r") as f1, open(new_file, "w") as f2:
            for line in f1:
                if old_str1 in line or old_str2 in line:
                    if old_str1 in line:
                        line = line.replace(old_str1, new_str1)
                        f2.write(line)

                    if old_str2 in line:
                        line = line.replace(old_str2, new_str2)
                        f2.write(line)
                else:
                    f2.write(line)
        command = r'/home/eccd/ldapadd -h 10.0.10.10 -p 31389 -c -x -D "cn=manager,dc=operator,dc=com" -w normal -f ' + new_file
#        print 'insert cmmand:', command
        os.system(command)
        time.sleep(5)
    except Exception as error:
        print "error in open new file:%s,or old file" %(new_file,old_file)
    finally:
        f1.close()
        f2.close()

if __name__ == '__main__':

    while 1:
        flag = raw_input("\033[0;32m***************************************************\n\n\033[0;31mpls continue input 1(delete) or 2(insert) or 3(check) or 4(quit):\n\n\n\033[0;36m1 delete continus misi    2  insert continuous misi    3 check continous misi status, check result.txt    4 quit\n\n\033[0;32m***************************************************")
        print '\033[m'
        flag = str(flag)
        if flag == "1":
            try:
                m = input("please input you want to delete continuous misi first num:")
                n = input("please input you want to delete continuous misi last num:")
                for i in range(m, n + 1):
                    release_imsi(i)
            except Exception as error:
                print '\033[7;31m请输入数字!!!!！\033[1;31;40m'
        if flag == "2":
            try:
                m = input("please input you want insert continuous imsi first num:")
                n = input("please input you want insert continuous imsi last num:")
                for i in range(m, n + 1):
                    insert_misi(i)
            except Exception as error:
                print '\033[7;31m请输入数字!!!!!\033[1;31;40m'
        if flag == "3":
            try:
                m = input("please input you want to check continuous misi first num:")
                n = input("please input you want to check continuous misi last num:")
                check_misi(m, n)
            except Exception as error:
                print '\033[7;31m请输入数字!!!!！\033[1;31;40m'
        if flag == "4":
            break
    print '\033[0;32m*********************\n\n\033[0;36myou already quit the tool !\n\n\033[0;32m*********************\n\n\033[m'
